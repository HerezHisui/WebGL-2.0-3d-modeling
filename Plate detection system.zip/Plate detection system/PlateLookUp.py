"""Database side of the plate system.

Everything that touches the plate database lives here: connecting to
'PlateDetect main.py', looking a plate up (exact or look-alike match),
and registering new plates. The scanner (plate_scanner.py) only calls the
functions below and knows nothing about SQLite.
"""
import importlib.util
import os
import sys
import time

# ---- Settings -----------------------------------------------------------
TOLERANT_MATCH = True   # accept look-alike misreads (0/O, 1/I, 8/B...)
DB_CACHE_SECONDS = 1.0  # how long a database answer is reused

# Characters OCR commonly mixes up are treated as the same when comparing
LOOKALIKE_FOLD = str.maketrans({"O": "0", "Q": "0", "D": "0", "I": "1",
                                "B": "8", "S": "5", "Z": "2", "G": "6"})

# ---- Connect to the database file (PlateDetect main.py) -----------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_MODULE_PATH = os.path.join(BASE_DIR, "PlateDetect main.py")

if not os.path.exists(DB_MODULE_PATH):
    sys.exit(f"Can't find 'PlateDetect main.py' next to this file:\n{BASE_DIR}")

_spec = importlib.util.spec_from_file_location("plate_db", DB_MODULE_PATH)
plate_db = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(plate_db)   # does NOT open the window

_cache = {}


# ------------------------------ Functions --------------------------------
def normalize(text):
    """Uppercase and strip everything except letters/digits."""
    return plate_db.normalize(text)


def fold(plate):
    """Collapse look-alike characters so misreads compare equal."""
    return plate.translate(LOOKALIKE_FOLD)


def same_plate(read, registered):
    """True if a scanned plate fits a registered one. A '?' (a character the
    scanner couldn't read) fits anything; look-alikes (0/O, 1/I...) fit."""
    if len(read) != len(registered):
        return False
    return all(a == "?" or fold(a) == fold(b) for a, b in zip(read, registered))


def closest_plate(plate, max_diff=2):
    """The registered plate that differs from `plate` in the fewest places
    (at most `max_diff`), or None. Only used to explain a denial."""
    best = None
    for row in plate_db.list_plates():
        reg = row[0]
        if len(reg) != len(plate):
            continue
        diff = sum(1 for a, b in zip(plate, reg) if a != b and a != "?")
        if diff <= max_diff and (best is None or diff < best[0]):
            best = (diff, reg)
    return best[1] if best else None


def check_plate(plate):
    """Look a scanned plate up in the database.

    Returns (authorized, registered_plate, owner, exact, closest).
    `closest` is only filled in for a denied plate: the nearest registered
    plate, to help see why it was denied.
    - Exact match first.
    - If TOLERANT_MATCH is on, a plate that differs only by look-alike
      characters (e.g. 0/O, 1/I, 8/B) or has one unreadable character ('?')
      also counts, but ONLY when exactly one registered plate fits - if it
      could be two different plates, it is denied.
    Answers are reused for a moment so the video isn't slowed down.
    """
    now = time.time()
    hit = _cache.get(plate)
    if hit and now - hit[0] < DB_CACHE_SECONDS:
        return hit[1]

    info = None
    if "?" not in plate and plate_db.plate_exists(plate):
        info = (True, plate, plate_db.get_owner(plate), True, None)
    elif TOLERANT_MATCH:
        matches = [row for row in plate_db.list_plates()
                   if same_plate(plate, row[0])]
        if len(matches) == 1:
            info = (True, matches[0][0], matches[0][1] or "", False, None)
    if info is None:
        info = (False, None, "", False, closest_plate(plate))
    _cache[plate] = (now, info)
    return info


def register_plate(plate, owner=""):
    """Add a plate to the database. Returns the stored plate, or None if it
    already exists, is empty, or has an unreadable character."""
    if "?" in plate:
        return None
    added = plate_db.add_plate(plate, owner)
    _cache.clear()          # make the new plate show up immediately
    return added