@echo off
REM Builds PlateDatabase.exe from "PlateDetect main.py"
REM Put this file in the same folder as "PlateDetect main.py", then double-click it.

cd /d "%~dp0"

echo Installing PyInstaller...
pip install pyinstaller

echo.
echo Building the exe (this can take a minute)...
pyinstaller --onefile --windowed --name PlateDatabase "PlateDetect main.py"

if exist "dist\PlateDatabase.exe" (
    copy /Y "dist\PlateDatabase.exe" "PlateDatabase.exe" >nul
    echo.
    echo Done! PlateDatabase.exe is now in this folder.
    echo Keep it together with PlateScanner.py and plates.db.
) else (
    echo.
    echo Build failed. Scroll up to see the error message.
)

echo.
pause
