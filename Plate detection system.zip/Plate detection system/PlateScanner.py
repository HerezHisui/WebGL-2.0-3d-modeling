import argparse
import os
import sys
import threading
import time
from collections import Counter, deque
from concurrent.futures import ThreadPoolExecutor

import cv2
import numpy as np
import pytesseract

pytesseract.pytesseract.tesseract_cmd = r"D:\computer\tesseract.exe"

# ---- Database side lives in PlateLookUp.py ----------------------------
import PlateLookUp as db

# ---- Settings -----------------------------------------------------------
GREEN = (0, 200, 0)
RED = (0, 0, 220)
YELLOW = (0, 220, 220)

CONFIRM_FRAMES = 2      # same reading needed this many times...
HISTORY_SIZE = 8        # ...within the last N readings
FALLBACK_SECONDS = 3.0  # plate in view this long without agreement -> show best guess anyway
MIN_PLATE_LEN = 5       # ignore very short OCR junk
HOLD_SECONDS = 0.8      # keep showing the last squares this long if a read is missed
DETECT_WIDTH = 640      # plate search runs on a frame shrunk to this width (faster)
MIN_CHAR_HEIGHT = 0.30  # a character must be >= 30% of the plate height
GLYPH_HEIGHT = 64       # each character is resized to this height before OCR
MIN_CHAR_CONF = 20      # OCR confidence below this -> character shown as '?'
MAX_UNKNOWN = 1         # a plate with more unreadable characters is ignored
GAP_LAYOUT = True       # wide gap on the plate = letters | numbers (e.g. MAU 7303)
GOOD_CONF = 60          # confident enough that no second look is needed
OCR_THREADS = 4         # characters are read in parallel
LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DIGITS = "0123456789"
CROP_VIEW_WIDTH = 480   # width of the "Plate Crop" window
RESULT_LINGER = 2.0     # seconds the Result window stays after the plate is gone
CAM_WIDTH, CAM_HEIGHT = 1280, 720   # requested camera resolution


# ---------------------- Step 1: find the plate area ----------------------
def _iou(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ix = max(0, min(ax + aw, bx + bw) - max(ax, bx))
    iy = max(0, min(ay + ah, by + bh) - max(ay, by))
    inter = ix * iy
    return inter / float(aw * ah + bw * bh - inter)


def find_plate_candidates(frame):
    """Return plate-like rectangles (x, y, w, h) in full-frame coordinates.

    Two methods are used: (A) a bright, filled rectangle - works for white /
    light plates even with embossed characters; (B) a rectangle found from
    edges - works for other plates.
    """
    scale = min(1.0, DETECT_WIDTH / frame.shape[1])
    small = cv2.resize(frame, None, fx=scale, fy=scale) if scale < 1.0 else frame
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    fh, fw = gray.shape

    found = []

    # (A) bright rectangle
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, bright = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    k = max(5, int(fw * 0.02))
    bright = cv2.morphologyEx(bright, cv2.MORPH_CLOSE,
                              cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    cnts, _ = cv2.findContours(bright, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:5]:
        x, y, w, h = cv2.boundingRect(c)
        if h == 0 or cv2.contourArea(c) < 0.01 * fw * fh:
            continue
        if 1.8 <= w / h <= 6.0 and cv2.contourArea(c) / (w * h) >= 0.75:
            found.append((x, y, w, h))

    # (B) rectangle from edges
    edges = cv2.Canny(cv2.bilateralFilter(gray, 11, 17, 17), 30, 200)
    cnts, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:15]:
        approx = cv2.approxPolyDP(c, 0.018 * cv2.arcLength(c, True), True)
        if len(approx) != 4:
            continue
        x, y, w, h = cv2.boundingRect(approx)
        if h == 0 or w < 80 * scale or not 1.8 <= w / h <= 6.0:
            continue
        if all(_iou((x, y, w, h), f) < 0.5 for f in found):
            found.append((x, y, w, h))

    return [tuple(int(v / scale) for v in b) for b in found]


# --------- Step 2: read the letters/numbers inside the plate area ----------
def segment_glyphs(gray, dark_text):
    """Find the box of every character inside the cropped plate."""
    h_img, w_img = gray.shape
    flag = cv2.THRESH_BINARY_INV if dark_text else cv2.THRESH_BINARY
    _, th = cv2.threshold(cv2.GaussianBlur(gray, (3, 3), 0), 0, 255,
                          flag + cv2.THRESH_OTSU)
    cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    boxes = []
    for c in cnts:
        x, y, w, h = cv2.boundingRect(c)
        if h < 0.12 * h_img:                      # specks, dirt, QR code
            continue
        if x <= 1 or y <= 1 or x + w >= w_img - 1 or y + h >= h_img - 1:
            continue                              # plate border / frame
        boxes.append([x, y, x + w, y + h])

    # Glare can split one character into pieces: join pieces that sit on top
    # of each other horizontally
    boxes.sort()
    merged = []
    for b in boxes:
        if merged:
            m = merged[-1]
            overlap = min(m[2], b[2]) - max(m[0], b[0])
            if overlap > 0.5 * min(m[2] - m[0], b[2] - b[0]):
                m[0], m[1] = min(m[0], b[0]), min(m[1], b[1])
                m[2], m[3] = max(m[2], b[2]), max(m[3], b[3])
                continue
        merged.append(b)

    glyphs = [(b[0], b[1], b[2] - b[0], b[3] - b[1]) for b in merged
              if MIN_CHAR_HEIGHT * h_img <= b[3] - b[1] <= 0.95 * h_img
              and (b[2] - b[0]) <= 1.5 * (b[3] - b[1])]
    if len(glyphs) >= 3:                          # drop odd-sized blobs
        med = float(np.median([g[3] for g in glyphs]))
        glyphs = [g for g in glyphs if 0.7 * med <= g[3] <= 1.3 * med]
    return glyphs


def binarize_variants(gray, dark_text):
    """Characters-white-on-black images made in different ways. Embossed or
    glossy plates break up under a single threshold, so several are tried."""
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    flag = cv2.THRESH_BINARY_INV if dark_text else cv2.THRESH_BINARY
    plain = cv2.threshold(blur, 0, 255, flag + cv2.THRESH_OTSU)[1]

    k = max(5, int(gray.shape[0] * 0.17)) | 1
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
    op = cv2.MORPH_BLACKHAT if dark_text else cv2.MORPH_TOPHAT
    local = cv2.morphologyEx(cv2.GaussianBlur(gray, (5, 5), 0), op, kernel)
    local = cv2.threshold(local, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    return [plain, local]


def classify_glyph(binary, box, whitelist):
    """OCR one character. Returns (char, confidence); char is '?' if unreadable."""
    x, y, w, h = box
    g = binary[y:y + h, x:x + w]
    s = GLYPH_HEIGHT / float(h)
    g = cv2.resize(g, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    g = cv2.copyMakeBorder(g, 30, 30, 30, 30, cv2.BORDER_CONSTANT, value=0)
    g = cv2.bitwise_not(cv2.GaussianBlur(g, (3, 3), 0))
    data = pytesseract.image_to_data(
        g, config=f"--psm 10 -c tessedit_char_whitelist={whitelist}",
        output_type=pytesseract.Output.DICT)
    best = ("?", -1.0)
    for t, c in zip(data["text"], data["conf"]):
        t = t.strip()
        if t and float(c) > best[1]:
            best = (t[0], float(c))
    return best


def split_letters_digits(glyphs):
    """Plates like 'MAU 7303' have a wide gap between the letters and the
    numbers. Returns the index where the numbers start, or None if no gap."""
    if not GAP_LAYOUT or len(glyphs) < 4:
        return None
    gaps = [glyphs[i + 1][0] - (glyphs[i][0] + glyphs[i][2])
            for i in range(len(glyphs) - 1)]
    widest = max(range(len(gaps)), key=gaps.__getitem__)
    others = [g for i, g in enumerate(gaps) if i != widest]
    med_w = float(np.median([g[2] for g in glyphs]))
    if gaps[widest] >= 2 * max(np.median(others), 1) and gaps[widest] >= 0.8 * med_w:
        return widest + 1
    return None


_pool = ThreadPoolExecutor(max_workers=OCR_THREADS)


def line_guess(binary, glyphs):
    """Read the whole row of characters at once. Used only to fill in
    characters that couldn't be read on their own."""
    x1 = max(0, min(g[0] for g in glyphs) - 10)
    x2 = min(binary.shape[1], max(g[0] + g[2] for g in glyphs) + 10)
    y1 = max(0, min(g[1] for g in glyphs) - 10)
    y2 = min(binary.shape[0], max(g[1] + g[3] for g in glyphs) + 10)
    row = cv2.resize(binary[y1:y2, x1:x2], None, fx=2, fy=2,
                     interpolation=cv2.INTER_AREA)
    row = cv2.copyMakeBorder(row, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=0)
    row = cv2.bitwise_not(cv2.GaussianBlur(row, (3, 3), 0))
    text = pytesseract.image_to_string(
        row, config=f"--psm 7 -c tessedit_char_whitelist={LETTERS + DIGITS}")
    return "".join(ch for ch in text if ch.isalnum())


def read_characters(frame, box):
    """Read the plate at `box`. Returns (text, chars).

    chars is a list of (character, (x1, y1, x2, y2)) in *frame* coordinates,
    left to right. A character that can't be read is '?'.
    """
    x, y, w, h = box
    gray = cv2.cvtColor(frame[y:y + h, x:x + w], cv2.COLOR_BGR2GRAY)
    dark_text = np.median(gray) >= 127            # dark letters on light plate

    glyphs = segment_glyphs(gray, dark_text)
    if len(glyphs) < MIN_PLATE_LEN:
        return "", []

    # Letters on the left of the gap, numbers on the right (when there is one)
    split = split_letters_digits(glyphs)
    variants = binarize_variants(gray, dark_text)

    def whitelist_for(i):
        if split is None:
            return LETTERS + DIGITS
        return LETTERS if i < split else DIGITS

    def read_one(i):
        whitelist = whitelist_for(i)
        best = ("?", -1.0)
        for v in variants:                        # second look only if unsure
            result = classify_glyph(v, glyphs[i], whitelist)
            if result[1] > best[1]:
                best = result
            if best[1] >= GOOD_CONF:
                break
        return best

    results = list(_pool.map(read_one, range(len(glyphs))))

    # Characters that couldn't be read alone: borrow them from a whole-row read
    unusable = [i for i, r in enumerate(results) if r[1] < MIN_CHAR_CONF]
    if unusable:
        guess = line_guess(variants[0], glyphs)
        if len(guess) == len(glyphs):
            for i in unusable:
                if guess[i] in whitelist_for(i):
                    results[i] = (guess[i], float(MIN_CHAR_CONF))

    chars = []
    for g, best in zip(glyphs, results):
        ch = best[0] if best[1] >= MIN_CHAR_CONF else "?"
        gx, gy, gw, gh = g
        chars.append((ch, (x + gx, y + gy, x + gx + gw, y + gy + gh)))

    if sum(1 for ch, _ in chars if ch == "?") > MAX_UNKNOWN:
        return "", []                             # too unreadable to trust
    return "".join(ch for ch, _ in chars), chars


def detect_plate(frame):
    """Return (plate_box, text, chars) for the first plausible plate."""
    for box in find_plate_candidates(frame):
        text, chars = read_characters(frame, box)
        if len(text) >= MIN_PLATE_LEN:
            return box, text, chars
    return None, None, []


# ------------- Background worker: keeps the video smooth ------------------
class PlateWorker(threading.Thread):
    """Runs detection + OCR on the newest frame in the background, so the
    live video never has to wait for Tesseract."""

    def __init__(self):
        super().__init__(daemon=True)
        self._lock = threading.Lock()
        self._new_frame = threading.Event()
        self._frame = None
        self._result = None          # (id, time, box, text, chars)
        self._result_id = 0
        self._running = True

    def submit(self, frame):
        with self._lock:
            self._frame = frame
        self._new_frame.set()

    def latest(self):
        with self._lock:
            return self._result

    def stop(self):
        self._running = False
        self._new_frame.set()

    def run(self):
        while self._running:
            self._new_frame.wait()
            self._new_frame.clear()
            with self._lock:
                frame = self._frame
            if frame is None or not self._running:
                continue
            try:
                box, text, chars = detect_plate(frame)
                crop = None
                if box is not None:
                    x, y, w, h = box
                    crop = frame[y:y + h, x:x + w].copy()
            except Exception as exc:          # never let the worker die
                print(f"Scan error: {exc}")
                continue
            with self._lock:
                self._result_id += 1
                self._result = (self._result_id, time.time(),
                                box, text, chars, crop)


# ------------------------------ Display ----------------------------------
def draw_crop_view(crop, box, chars):
    """Enlarged cropped plate with a square around every letter/number the
    scanner found. The squares are only 'scanned' markers (yellow); the
    verdict is shown in the separate Result window."""
    scale = CROP_VIEW_WIDTH / crop.shape[1]
    view = cv2.resize(crop, None, fx=scale, fy=scale,
                      interpolation=cv2.INTER_CUBIC)
    ox, oy = box[0], box[1]
    for ch, (x1, y1, x2, y2) in chars:
        p1 = (int((x1 - ox) * scale), int((y1 - oy) * scale))
        p2 = (int((x2 - ox) * scale), int((y2 - oy) * scale))
        cv2.rectangle(view, p1, p2, YELLOW, 2)
        cv2.putText(view, ch, (p1[0], max(p1[1] - 4, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, YELLOW, 2)
    return view


def make_result_view(plate, info, unsure=False):
    """The pop-up verdict: big green panel if authorized, red if not.
    Shows the owner's name when the plate is registered."""
    authorized, registered, owner, exact, closest = info
    color = GREEN if authorized else RED
    view = np.full((290, 600, 3), color, np.uint8)
    white = (255, 255, 255)
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(view, plate, (20, 65), font, 1.5, white, 4)
    cv2.putText(view, "AUTHORIZED" if authorized else "UNAUTHORIZED",
                (20, 125), font, 1.4, white, 4)
    if not authorized:
        cv2.putText(view, "Not in the database", (20, 170), font, 0.9, white, 2)
        if closest:
            cv2.putText(view, f"Closest registered: {closest}",
                        (20, 205), font, 0.65, white, 2)
    if authorized and owner:
        cv2.putText(view, f"Owner: {owner}", (20, 170), font, 0.9, white, 2)
    if authorized and not exact:
        cv2.putText(view, f"Close match - registered as {registered}",
                    (20, 200), font, 0.65, white, 2)
    if unsure:
        cv2.putText(view, "Low confidence - readings kept changing",
                    (20, 232), font, 0.65, white, 2)
    cv2.putText(view, "Go through" if authorized else "Do not enter",
                (20, 272), font, 0.9, white, 2)
    return view


def draw_main(frame, box, text, votes=0):
    """Live view: just marks the plate being scanned (no verdict here)."""
    if box is not None:
        x, y, w, h = box
        cv2.rectangle(frame, (x, y), (x + w, y + h), YELLOW, 2)
    msg = (f"Reading: {text}  [{votes}/{CONFIRM_FRAMES}]" if text
           else "Scanning...")
    cv2.rectangle(frame, (0, 0), (frame.shape[1], 50), (80, 80, 80), -1)
    cv2.putText(frame, msg, (10, 34), cv2.FONT_HERSHEY_SIMPLEX,
                0.9, (255, 255, 255), 2)


# ------------------------- Camera (Iriun Webcam) --------------------------
# Iriun Webcam shows up on the PC as a normal webcam, so it is opened by its
# camera number. The number depends on what else is plugged in - use --list.
def open_camera(source):
    """Open a camera number (e.g. Iriun) or a video file. Returns None on failure."""
    if str(source).isdigit():
        index = int(source)
        # DirectShow is the backend Iriun works best with on Windows
        backends = [cv2.CAP_DSHOW, cv2.CAP_ANY] if os.name == "nt" else [cv2.CAP_ANY]
        for backend in backends:
            cap = cv2.VideoCapture(index, backend)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAM_WIDTH)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAM_HEIGHT)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)   # keep the live view low-lag
                return cap
            cap.release()
        return None
    cap = cv2.VideoCapture(str(source))
    return cap if cap.isOpened() else None


def list_cameras(max_index=8):
    """Show every camera number that works, with a preview, so you can spot Iriun."""
    print("Looking for cameras (Iriun must be running on the PC and phone)...")
    found = []
    for i in range(max_index):
        cap = open_camera(i)
        if cap is None:
            continue
        ok, frame = cap.read()
        cap.release()
        if ok:
            h, w = frame.shape[:2]
            print(f"  camera {i}: working, {w}x{h}")
            found.append((i, frame))
    if not found:
        print("No cameras found. Check that Iriun is open on both the PC and phone.")
        return
    print("A preview of each camera is open - the one showing your phone's view "
          "is the Iriun number. Press any key to close.")
    for i, frame in found:
        cv2.imshow(f"camera {i}", frame)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print("Run:  python plate_scanner.py --source <number>")


# ------------------------------- Main ------------------------------------
def scan(source):
    # A single picture is reused every loop; anything else is a camera/video
    still = None
    if os.path.isfile(str(source)):
        still = cv2.imread(str(source))
    cap = None
    if still is None:
        cap = open_camera(source)
        if cap is None:
            sys.exit(f"Could not open source: {source}\n"
                     "For Iriun: open Iriun Webcam on the PC and the phone app "
                     "(same Wi-Fi), then run  --list  to find its camera number.")

    worker = PlateWorker()
    worker.start()

    history = deque(maxlen=HISTORY_SIZE)
    seen_id = 0
    result_open = False
    last_confirmed = 0.0
    seen_since = None     # when the current plate first came into view
    current_key = None    # the plate currently winning the vote
    last_seen = 0.0

    while True:
        if still is not None:
            frame = still
        else:
            ok, frame = cap.read()
            if not ok:
                break

        worker.submit(frame)          # background scan of the newest frame
        display = frame.copy()

        result = worker.latest()
        box = text = None
        if result:
            rid, stamp, box, text, chars, crop = result
            if rid != seen_id:        # a fresh reading
                seen_id = rid
                history.append(text)  # add it to the vote
                if crop is not None:  # update the Plate Crop window
                    cv2.imshow("Plate Crop", draw_crop_view(crop, box, chars))
            if time.time() - stamp > HOLD_SECONDS:
                box, text = None, None              # reading is stale

        now = time.time()
        if text:
            last_seen = now
            if seen_since is None:
                seen_since = now
        elif now - last_seen > 1.0:
            seen_since = None

        # Vote across recent readings to filter out OCR noise. Readings that
        # differ only by look-alike characters (0/O, 1/I, 8/B...) count as the
        # same reading, and the most common spelling of them is used.
        groups = Counter(db.fold(t) for t in history if t)
        confirmed_plate = None
        unsure = False
        votes = 0
        if groups:
            key, votes = groups.most_common(1)[0]
            if groups.get(current_key) == votes:
                key = current_key       # on a tie, keep the current plate
            current_key = key
            spelling = Counter(t for t in history if t and db.fold(t) == key)
            best = spelling.most_common(1)[0][0]
            if votes >= CONFIRM_FRAMES:
                confirmed_plate = best
            elif seen_since is not None and now - seen_since > FALLBACK_SECONDS:
                confirmed_plate = best      # never agreed: show best guess
                unsure = True

        # Once the letters/numbers are confirmed, pop up the verdict window
        if confirmed_plate:
            last_confirmed = now
            result_open = True
            cv2.imshow("Result", make_result_view(confirmed_plate,
                                                  db.check_plate(confirmed_plate),
                                                  unsure))
        elif result_open and now - last_confirmed > RESULT_LINGER:
            result_open = False
            try:
                cv2.destroyWindow("Result")
            except cv2.error:
                pass

        draw_main(display, box, text, votes)
        cv2.imshow("Plate Scanner", display)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("r") and confirmed_plate:
            if "?" in confirmed_plate:
                print(f"Can't register {confirmed_plate}: a character was unreadable")
            elif db.register_plate(confirmed_plate):
                print(f"Registered: {confirmed_plate}")

    worker.stop()
    if cap is not None:
        cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plate scanner")
    parser.add_argument("--source", default="0",
                        help="camera number (Iriun), video path, or image path")
    parser.add_argument("--list", action="store_true",
                        help="show available cameras to find the Iriun number")
    parser.add_argument("--strict", action="store_true",
                        help="exact plate match only (no look-alike tolerance)")
    args = parser.parse_args()
    if args.strict:
        db.TOLERANT_MATCH = False
    if args.list:
        list_cameras()
    else:
        scan(args.source)